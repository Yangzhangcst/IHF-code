function [ImC]  = compu_centroid( img )
% COMPU_CENTROID computes centroid of contour
% INPUT 
%      img should be a binary image
% OUTPUT
%      ImC is the position of img 
img = img(:,:,1);
img = ~img;%invert image

[B,L] = bwboundaries(img,'noholes');

STATS = regionprops(L,'basic');%basic includes feature of 'Area','Centroid' and 'Boundingbox'

for i = 1:length(STATS)   
    ImC = STATS(i).Centroid;
end
return
    