%-------- computing height functions feature for images --------%

addpath common_IHF;
clear;

%-------- file name parameters ----
% MPEG-7:    D:\MATLABR2008b\work\02_MPEG7_remove_holes
% Tari1000:  D:\MATLABR2008b\work\Tari_bmp
% ETH-80:    D:\MATLABR2008b\work\ETH-80
f_structure = dir('D:\Matlab 2012b\work\mpeg7');  % put all the files in a structure
m = length(f_structure);
%m=302;
ifname = cell(1, m-2);
for i = 3 : m             % batch process
    ifname{i-2} = strcat('D:\Matlab 2012b\work\mpeg7\', f_structure(i).name);
end

%---------- sample every image and get scale values ----
IHFs      = cell(1, m-2);
IHF2s     = cell(1, m-2);
n_contour = 100;
%n_contour = 60;

T1 = fix(clock); % start time
for k = 1:m-2
    %------ Centroid of feature
	ims    = double(imread(ifname{k}));
    
    %------ Contour extraction
    ims    = ims(:,:,1);             % image preprocess 1: for binary images, im(:,:,1) is simply the image itself. here is to avoid colour image data, which can't be processed by the 'extract_longest_cont' function
%     im    = 255 - im;              % additional process: for 255 background and 0 foreground (check the boundary, or may cause fatal error!)
%     im(im < 200) = 0;              % image preprocess 2: omit noise pixel values
%     im(im > 0) = 255;
    [len, wid] = size(ims);
    im2        = zeros(len+2, wid+2);
    im2(2:len+1,2:wid+1) = ims;       % image preprocess 3: add empty lines around the object, avoiding contour error (which will make all later work useless!)
    im3        = im2';               % mirror image

    Cs         = extract_longest_cont(im2, n_contour);
    Cs2        = extract_longest_cont(im3, n_contour); 
    
%     % have to check, contour error?
%        figure(1);
%        imshow(255*ones(size(im2))); hold on;
% %        plot(Cs2(:,1), Cs2(:,2), 'k'); hold on; % boundary curve
%        plot(Cs(:,1), Cs(:,2), 'ok', 'MarkerFaceColor', 'k'); hold on; % all sample points
%        plot(Cs(100,1), Cs(100,2), 'sr', 'MarkerFaceColor', 'r'); hold on;
%        % object point
%        plot(Cs(99,1), Cs(99,2), 'ob', 'MarkerFaceColor', 'b');
%        plot(Cs(1,1), Cs(1,2), 'ob', 'MarkerFaceColor', 'b'); % neighbor points
%        saveas(figure(1), strcat('D:\Matlab 2012b\work\temp\MPEG7_01\', f_structure(k+2).name, '.jpg'));
%        close(figure(1));
%     %
    
    %----- IHF for all landmark points --
    ihf      = compu_contour_IHF(Cs);
    ihf2     = compu_contour_IHF(Cs2);
    IHFs{k}  = ihf;
    IHF2s{k} = ihf2;
    
    fprintf('Process shape %i end \n', k);
end
T2 = fix(clock); % end time

%---- save MSTA for all shapes
save('IHFs for MPEG7 with max-normal.mat', 'IHFs');  % sshr
save('IHF2s for MPEG7 with max-normal.mat', 'IHF2s');  % sshr2

a = 1;
