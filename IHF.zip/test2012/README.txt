This fold contains all necessary code files for shape matching with Improved height functions (IHF).


The matching process includes the following four steps:

batch_IHF.m           : calculating the Improved height functions features for all shapes in some data set, and storing them in one .mat file
hisIHF.m              : smoothing and local normalization
IHF_shape_retrieval.m : DP matching based on Improved  height functions
IHF_SC.m              : improving shape similarity values by shape complexity

There are some parameters in the codes, and they should be changed by modifying the codes in specific places.

All necessary functions to run the above code files are put in the fold 'commom_IHF'. Some of these functions are implemented by directly using or slightly changing the source codes of height functions(HFs) provided online by Wang amd Bai.


For more details, please refer to

1.SUN Guo-dong, ZHANG Yang, LI Ping, MEI Shu-zheng, ZHAO Da-xing. Feature description of exact height function used in fast shape retrieval. Editorial Office of Optics and Precision Engineering, 2017, 25(1): 224-235.

2.Wang, J., Bai, X., You, X., Liu, W., Latecki, L.J., Shape Matching and Classification Using Height Functions, Pattern Recognition Letters (PRL), 2012, 33(2):134-143.

3.http://mc.eistar.net/~xbai/
